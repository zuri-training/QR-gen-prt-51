var qr_container = document.querySelector(".qr-container")
var inner_qr_container = document.querySelector(".inner-qr-container")
var inner_qr_container = document.querySelector(".first-qr-container")
var changer1 = document.querySelector(".changer1")
var changer2 = document.querySelector(".changer2")

var color_box = document.querySelector(".color-box")
var inner_boxA= document.querySelector(".inner-boxA")
var inner_boxB = document.querySelector(".inner-boxB")
// 2
var color_boxB =document.querySelector(".color-boxB")
var inner_box_innerB =document.querySelector(".inner-box-innerB")
var inner_box_innerB2 =document.querySelector(".inner-box-innerB2")
// 3
var color_boxC = document.querySelector(".color-boxC")
var inner_box_innerC = document.querySelector(".inner-box-innerC")
var inner_box_innerC2 =document.querySelector(".inner-box-innerC2")
// 4
var inner_boxD = document.querySelector(".inner-boxD")
var color_boxD =document.querySelector(".color-boxD")
var inner_boxD2 = document.querySelector(".inner-boxD2")
// 5
var inner_boxE = document.querySelector(".inner-boxE")
var color_boxE = document.querySelector(".color-boxE")
var inner_boxE2 = document.querySelector(".inner-boxE2")
// 6
var inner_boxF = document.querySelector(".inner-boxF")
var color_boxF = document.querySelector(".color-boxF")
var inner_boxF2 = document.querySelector(".inner-boxF2")



color_box.addEventListener("click", ()=>{
    changer2.style.background='#A00909';
})
inner_boxA.addEventListener("click", ()=>{
    changer2.style.background='#F70303';
})
inner_boxB.addEventListener("click", ()=>{
    changer2.style.background='#E8B5B5';
})
//2
color_boxB.addEventListener("click", ()=>{
    changer2.style.background='#A29B0A';
})
inner_box_innerB.addEventListener("click", ()=>{
    changer2.style.background='#FFF50F';
})
inner_box_innerB2.addEventListener("click", ()=>{
    changer2.style.background='#F9F6BF';
})
// 3
color_boxC.addEventListener("click", ()=>{
    changer2.style.background='#313B9B';
})
inner_box_innerC.addEventListener("click", ()=>{
    changer2.style.background='#4959E9';
})
inner_box_innerC2.addEventListener("click", ()=>{
    changer2.style.background='#A4ACF4';
})
// 4
color_boxD.addEventListener("click", ()=>{
    changer2.style.background='#235B0F';
})
inner_boxD.addEventListener("click", ()=>{
    changer2.style.background='#30A806';
})
inner_boxD2.addEventListener("click", ()=>{
    changer2.style.background='#70E747';
})
// 5
color_boxE.addEventListener("click", ()=>{
    changer2.style.background='#C17605';
})
inner_boxE.addEventListener("click", ()=>{
    changer2.style.background='#EEA83F';
})
inner_boxE2.addEventListener("click", ()=>{
    changer2.style.background='#EEA83F';
})
// 6
color_boxF.addEventListener("click", ()=>{
    changer2.style.background='#670469';
})
inner_boxF.addEventListener("click", ()=>{
    changer2.style.background='#A300A7';
})
inner_boxF2.addEventListener("click", ()=>{
    changer2.style.background='#E82AEC';
})